
const express = require('express');
const line = require('@line/bot-sdk');
const axios = require('axios');

const app = express();
app.use(express.json());

const config = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET
};

const client = new line.Client(config);

app.post('/webhook', line.middleware(config), async (req, res) => {
  const events = req.body.events;
  for (let event of events) {
    if (event.type === 'message' && event.message.type === 'text') {
      const userMessage = event.message.text;
      try {
        const gptReply = await fetchGPT(userMessage);
        await client.replyMessage(event.replyToken, {
          type: 'text',
          text: gptReply
        });
      } catch (error) {
        console.error('Error replying:', error);
        await client.replyMessage(event.replyToken, {
          type: 'text',
          text: 'ขออภัย ระบบมีปัญหาชั่วคราว กรุณาลองใหม่อีกครั้งนะครับ'
        });
      }
    }
  }
  res.sendStatus(200);
});

async function fetchGPT(userMessage) {
  const response = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'คุณคือเซลล์ผู้เชี่ยวชาญเรื่องรถยนต์ไฟฟ้า Aion ตอบคำถามให้ลูกค้าอย่างมืออาชีพ สุภาพ และเข้าใจง่าย'
      },
      {
        role: 'user',
        content: userMessage
      }
    ]
  }, {
    headers: {
      Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    }
  });

  return response.data.choices[0].message.content;
}

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`LINE bot is running on port ${port}`));
